#include <stdio.h>

int main(){
	int ret;
	ret = system("man ls");
	return ret;
}
