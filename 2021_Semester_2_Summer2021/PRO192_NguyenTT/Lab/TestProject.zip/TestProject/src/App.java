import employees.Employee;
import employees.EmployeeList;
import employees.Menu;
import employees.Utils;

public class App {
    public static void main(String[] args) throws Exception {
        Menu menu = new Menu();
        menu.addMenuItem("1. ADD NEW EMPLOYEE");
        menu.addMenuItem("2. REMOVE AN EMPLOYEE");
        menu.addMenuItem("3. PROMOTING THE EMPLOYEE'S SALARY");
        menu.addMenuItem("4. PRINT THE LIST");
        menu.addMenuItem("5. SAVE TO FILES");
        menu.addMenuItem("6. QUIT");
        

        String fileName = "data.txt";
        EmployeeList list = new EmployeeList();
        int choiceUser;
        do{
            Utils.clear();
            choiceUser = menu.getUserChoice();
            switch(choiceUser){
                case 1:
                    list.addEmployee();
                    break;
                case 2:
                    list.removeEmployee();
                    break;
                case 3:
                    list.promoteSalary();
                    break;
                case 4:
                    list.listEmployee();
                    break;
                case 5:
                    list.save(fileName);
                    break;
                case 6:
                    System.exit(0);
                    break;
            }
        
        }while(choiceUser != 6);

    }
}
