package employees;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.Vector;

public class EmployeeList extends Vector<Employee> {

    Scanner sc = new Scanner(System.in);
    public EmployeeList(){
        super();
    }

    public void loadDataFromFile(String fileName){
        try{
            File f = new File(fileName);
            if(!f.exists()) return;
            FileReader fr = new FileReader(f);
            BufferedReader bf = new BufferedReader(fr);
            String data;
            while((data = bf.readLine()) != null){
                StringTokenizer stk = new StringTokenizer(data, ",");
                String code = stk.nextToken().toUpperCase();
                String name = stk.nextToken().toUpperCase();
                int salary = Integer.parseInt(stk.nextToken());
                add(new Employee(code, name, salary));
            }
            bf.close();
            fr.close();
        }catch(Exception ex){
                System.out.println(ex);
        }
    }

    public void save(String fileName){
        if(size() == 0){
            System.out.println("Empty list!");
        }else{
            try{
                File f = new File(fileName);
                FileWriter fw = new FileWriter(f);
                BufferedWriter pw = new BufferedWriter(fw);
                for(Employee e: this){
                    pw.write(
                        e.getCode() + "," +
                        e.getName() + "," +
                        e.getSalary()
                    );
                }
                pw.close(); fw.close();
            }catch(Exception e){
                System.out.println(e);
            }
        }
    }

    public void addEmployee(){ 

        System.out.println(
            "   ___      _     _   _____                _                       \n" +
            "  / _ \\    | |   | | |  ___|              | |                      \n" +
            " / /_\\ \\ __| | __| | | |__ _ __ ___  _ __ | | ___  _   _  ___  ___ \n" +
            " |  _  |/ _` |/ _` | |  __| '_ ` _ \\| '_ \\| |/ _ \\| | | |/ _ \\/ _ \\\n" +
            " | | | | (_| | (_| | | |__| | | | | | |_) | | (_) | |_| |  __/  __/\n" +
            " \\_| |_/\\__,_|\\__,_| \\____/_| |_| |_| .__/|_|\\___/ \\__, |\\___|\\___|\n" +
            "                                    | |             __/ |          \n" +
            "                                    |_|            |___/           ");
        System.out.println("Instructions: ");
        System.out.println("- The [CODE] must be match the pattern (E _ _ _) - starts with letter E and 3 digits");
        System.out.println("- The [NAME] must not be empty!");
        System.out.println("- The [SALARY] must not be lower than 0!");
        System.out.println(Utils.printChar('═', 100));
        String newCode, newName;
        int newSalary;
        boolean[] cont = {true};
        do{
            do{
                System.out.print("CODE (E000): "); newCode = sc.nextLine().toUpperCase();
                if(newCode.matches("^E\\d{3}$")){
                    int pos = find(newCode);
                    if(pos != -1){
                        Utils.showText("This CODE is already existed!");
                    }else{
                        break;
                    }
                }else{
                    Utils.showText("This CODE is not valid!");
                }
            }while(true);
    
            do{
                System.out.print("NAME: "); newName = sc.nextLine().toUpperCase();
                if(!newName.isEmpty()){
                    break;
                }else{
                    Utils.eraseLine(1);
                }
            }while(true);
    
            do{
                System.out.print("SALARY: "); 
                try{
                    newSalary = Integer.parseInt(sc.nextLine());
                    if(newSalary < 0){
                        Utils.eraseLine(1);
                    }else{
                        break;
                    }
                    
                }catch(Exception e){
                    Utils.eraseLine(1);
                }
            }while(true);
    
            add(new Employee(
                newCode,
                newName,
                newSalary
            ));
            Utils.continueTask(new YesNoEventHandler(){

                @Override
                public void yes() {
                    
                }

                @Override
                public void no() {
                    cont[0] = false;
                }
                
            });
        }while(cont[0]);
    }
    
    public void removeEmployee(){
        System.out.println(
            "______                                     _____                   _                                       \n" +
            "| ___ \\                                   |  ___|                 | |                                      \n"+
            "| |_/ / ___  _ __ ___    ___ __   __ ___  | |__  _ __ ___   _ __  | |  ___   _   _   ___   ___             \n"+
            "|    / / _ \\| '_ ` _ \\  / _ \\\\ \\ / // _ \\ |  __|| '_ ` _ \\ | '_ \\ | | / _ \\ | | | | / _ \\ / _ \\            \n"+
            "| |\\ \\|  __/| | | | | || (_) |\\ V /|  __/ | |___| | | | | || |_) || || (_) || |_| ||  __/|  __/            \n"+
            "\\_| \\_|\\___||_| |_| |_| \\___/  \\_/  \\___| \\____/|_| |_| |_|| .__/ |_| \\___/  \\__, | \\___| \\___|            \n"+ 
            "                                                           | |                __/ |                        \n"+
            "                                                           |_|               |___/             "
        );
        System.out.println(Utils.printChar('═', 100));
        boolean[] cont = {true};
        String newCode;
            do{
                if(this.size() > 0){
                    do{
                        System.out.print("CODE (E000): "); newCode = sc.nextLine().toUpperCase();
                        if(newCode.matches("^E\\d{3}$")){
                            int pos = find(newCode);
                            if(pos != -1){
                                this.remove(pos);
                                System.out.println("Remove successfully!");
                                break;
                            }else{
                                Utils.showText("This CODE is not existed!");
                            }
                        }else{
                            Utils.showText("This CODE is not valid!");
                        }
                    }while(true);    
                }else{
                    System.out.println("There is no data!");
                }

                Utils.continueTask(new YesNoEventHandler(){
    
                    @Override
                    public void yes() {
                        
                    }
    
                    @Override
                    public void no() {
                        cont[0] = false;
                    }
                    
                });
            }while(cont[0]);

    }

    public void promoteSalary(){
        System.out.println(
"______                         _          _____         _    \n"+
"| ___ \\                       | |        /  ___|       | |                    \n"+
"| |_/ / ___  _ __ ___    ___  | |_  ___  \\ `--.   __ _ | |  __ _  _ __  _   _ \n"+
"|    / / _ \\| '_ ` _ \\  / _ \\ | __|/ _ \\  `--. \\ / _` || | / _` || '__|| | | |\n"+
"| |\\ \\|  __/| | | | | || (_) || |_|  __/ /\\__/ /| (_| || || (_| || |   | |_| |\n"+
"\\_| \\_|\\___||_| |_| |_| \\___/  \\__|\\___| \\____/  \\__,_||_| \\__,_||_|    \\__, |\n"+
"                                                                         __/ |\n"+
"                                                                        |___/ \n"
        );
        System.out.println(Utils.printChar('═', 100));
        String newCode;
        int newSalary;
        Employee e;
        boolean[] cont = {true};
        do{
            do{
                System.out.print("CODE (E000): "); newCode = sc.nextLine().toUpperCase();
                if(newCode.matches("^E\\d{3}$")){
                    int pos = find(newCode);
                    if(pos == -1){
                        Utils.showText("This CODE is not existed!");
                    }else{
                        e = this.get(pos);
                        break;
                    }
                }else{
                    Utils.showText("This CODE is not valid!");
                }
            }while(true);

            do{
                System.out.print("OLD SALARY IS "+ e.getSalary() +", NEW SALARY: "); 
                try{
                    newSalary = Integer.parseInt(sc.nextLine());
                    if(newSalary < 0){
                        Utils.eraseLine(1);
                    }else if(newSalary < e.getSalary()){
                        Utils.showText("New salary must be greater than old salary");
                    }
                    else{
                        break;
                    }
                    
                }catch(Exception ex){
                    Utils.eraseLine(1);
                }
            }while(true);

            e.setSalary(newSalary);

            Utils.continueTask(new YesNoEventHandler(){

                @Override
                public void yes() {
                    
                }

                @Override
                public void no() {
                    cont[0] = false;
                }
                
            });
        }while(cont[0]);
    }

    public void listEmployee(){
        int maxWidthCol1 = 4, maxWidthCol2 = 4, maxWidthCol3 = 6;
        
        for(Employee e: this){
            if(maxWidthCol1 < e.getCode().length()){
                maxWidthCol1 = e.getCode().length();
            }

            if(maxWidthCol2 < e.getName().length()){
                maxWidthCol2 = e.getName().length();
            }

            if(maxWidthCol3 < String.valueOf(e.getSalary()).length()){
                maxWidthCol3 = String.valueOf(e.getSalary()).length();
            }
        }

        System.out.println("|CODE" + Utils.printChar(' ', maxWidthCol1 - 4) + 
                            "|NAME" + Utils.printChar(' ', maxWidthCol2 - 4) + 
                            "|SALARY" + Utils.printChar(' ', maxWidthCol3 - 6) + "|");

        for(Employee e: this){
            String name = e.getName();
            String code = e.getCode();
            int salary = e.getSalary();

            System.out.println("|"+ code + Utils.printChar(' ', maxWidthCol1 - code.length()) + 
                            "|"+ name + Utils.printChar(' ', maxWidthCol2 - name.length()) + 
                            "|" + salary + Utils.printChar(' ', maxWidthCol3 - String.valueOf(salary).length()) + "|");
        }

        System.out.println("Press Enter to back to the menu");
        try {
            System.in.read();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    private int find(String code){
        for(int i = 0; i < this.size(); i++){
            if(this.get(i).getCode().equals(code)){
                return i;
            }
        }
        return -1;
    }
}
