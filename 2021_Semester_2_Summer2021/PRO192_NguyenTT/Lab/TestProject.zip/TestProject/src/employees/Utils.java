package employees;

import java.io.IOException;
import java.util.Scanner;

import javax.swing.Action;

public class Utils {
    public static void clear(){
        System.out.print("\033\143");
    }

    public static String printChar(char c, int n){
        String ret = "";
        for(int i = 0; i < n;i++){
            ret += c;
        }
        return ret;
    }

    public static void eraseLine(int n){
        System.out.print(String.format("\033[%dA", n));
        System.out.print("\033[2K");
    }

    public static void showText(String text){
        Utils.eraseLine(1);
        System.out.print(text);
        try {
            System.in.read();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Utils.eraseLine(1);
    }

    public static void continueTask(YesNoEventHandler handler){
        
        Scanner sc = new Scanner(System.in);
        try{
            do{
                System.out.print("Do you want to continue? (y/n): ");
                char choice = sc.nextLine().toLowerCase().charAt(0);
                if(choice == 'y'){
                    handler.yes();
                    break;
                }else if(choice == 'n'){
                    handler.no();
                    break;
                }else{
                    eraseLine(1);
                }
            }while(true);
            
        }catch(Exception e){
            eraseLine(1);
        }
        
    }

    
}
