package employees;

public interface YesNoEventHandler{
    public void yes();
    public void no();
}