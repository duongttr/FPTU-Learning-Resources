/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;

import DTO.*;

/**
 *
 * @author jaydentran1909
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        Colony obj1 = new BeeColony("honey", "land", 2000);
        System.out.println(obj1);
        obj1.grow();
        obj1.reproduce();
        University obj2 = new FPTUni("FPT", "Cantho", 100000);
        System.out.println(obj2); 
        obj2.enroll(); 
        obj2.educate();
        Organization df= new BeeColony("wasp", "land", 3000); 
        System.out.println(df);
        ((BeeColony)df).createWorker();
        df = new FPTUni("FPT", "Hanoi",100000); 
        System.out.println(df);
        ((FPTUni)df).createWorker();
    }
}
