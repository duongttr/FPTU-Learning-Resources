import java.util.Arrays;

public class Graph2 {
    int[][] a;
    int n;
    void setAMatrix(int[][] b, int m) {
        this.a = b;
        this.n = m;
    }
    void Dijkstra(int s) {
        int[] d = new int[this.n];
        int maxC = 999999999;
        Arrays.fill(d, maxC);
        d[s] = 0;
        boolean[] visited = new boolean[n];
        Arrays.fill(visited, false);
        while (true) {
            int v = -1;
            int max_dis = 99999999;
            for (int i = 0; i < n; i++) {
                if (d[i] < max_dis && visited[i] == false) {
                    max_dis = d[i];
                    v = i;
                }
            }
            if (v == -1) {
                break;
            }
            visited[v] = true;

            for (int u = 0; u < n; u++) {
                if (d[u] > d[v] + a[u][v] && a[u][v] > 0) {
                    d[u] = d[v] + a[u][v];
                }
            }
        }
        for (int i = 0; i < n; i++) {
            if (d[i] != maxC) {
                System.out.println("Distance from " + s + " to " + i + " = " + d[i]);
            } else {
                System.out.println("There have no path from " + s + " to " + i);
            }
        }

    }

}