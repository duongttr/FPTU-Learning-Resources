import java.util.HashMap;

public class App {
    public static void main(String[] args) {
        HashMap<Character, Double> dict1=new HashMap<>();
        dict1.put('a', 0.5);
        dict1.put('b', 0.25);
        dict1.put('c', 0.15);
        dict1.put('d', 0.15);
        dict1.put('e', 0.35);

        HuffmanTree b = new HuffmanTree();
        b.buildTreeFromDict(dict1);
        HashMap<String,Character> table1 = b.getTranslate(b);
        System.out.println(table1+"\n");

        
        HashMap<Character,Integer> dict2=new HashMap<>();
        dict2.put('a', 15);
        dict2.put('b', 5);
        dict2.put('c', 45);
        dict2.put('d', 12);
        dict2.put('e', 48);
        dict2.put('f', 58);
        dict2.put('g', 8);

        HuffmanTree c=new HuffmanTree();
        c.buildTreeFromDict2(dict2);
        HashMap<String,Character> table2=b.getTranslate(c);
        System.out.println(table2+"\n");
    
        HuffmanTree a=new HuffmanTree();
        a.buildTree("ABCDEFGHHqwweriouwejsdklcnxvm,shjdiroweurio128039{}");
        HashMap<String,Character> table=a.getTranslate(a);
        System.out.println(table);

    }
}
