package Menu;

public interface MenuTask {
    public void task();
}
