package Utils;

public interface Functions {
    public void showInfo();
    public void addInjection();
    public void updateInjection();
    public void deleteInjection();
    public void storeToFile();
    public void loadFromFile();
    public void searchByStudentId();
}
